WITH fct_yt_trending AS (
    SELECT 
    video_title,
    view_count
    FROM {{ref('fct_yt_trending')}}
    {{ limit_data_in_dev('video_publication_timestamp', 3) }}
)
SELECT
    video_title,
    {{ cents_to_dollars('view_count') }} as amount
FROM fct_yt_trending

