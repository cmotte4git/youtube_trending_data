{% macro limit_data_in_dev(column_name, dev_days_delta=3) -%}
{% if target.name == 'dev' -%}
WHERE {{ column_name }} >= current_date() - {{ dev_days_delta}}
{% endif -%}
{%- endmacro %}